package Database;

import java.sql.Connection;
import java.sql.DriverManager;

public class testconn {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/sql_employees"; // Replace with your DB URL
        String user = "root"; // Replace with your DB username
        String password = "Kun@l2024"; // Replace with your DB password

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            if (conn != null) {
                System.out.println("Database connected successfully!");
            } else {
                System.out.println("Failed to connect to the database.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred while connecting to the database.");
            e.printStackTrace();
        }
    }
}

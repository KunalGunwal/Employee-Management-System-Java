package GUI.General;

// to run the project;
public class GUIRunner {
    

    private GUIRunner() {}
    
    // main class (ye hi runnable class h)

    public static void main(String[] args) throws ClassNotFoundException {
        new GUIInfo();
    }

}
